import { configureStore } from "@reduxjs/toolkit";
import { businessProfilesApi } from "./businessProfilesApi";
import { transportersApi } from "./transportersApi";
import { promotersApi } from "./promotersApi";
import {categoryApi} from "./categoryApi";
import {contractsApi} from "./contractsApi";
import { contractTrucksApi } from "./contractTrucksApi";
import {productsApi} from "./productsApi";
import { userProfilesCommonApi } from "./userProfilesCommonApi";
import { authApi } from "./authApi";
import { trucksApi } from "./trucksApi";
import { driversApi } from "./driversApi";
import { truckTripApi } from "./truckTripApi";
import { driverTruckMappingApi } from "./driverTruckMappingApi";
import { roleAccessApi } from "./roleAccessApi";
import { userAccessApi } from "./userAccessApi";
import { sellerInvoiceApi } from "./sellerInvoiceApi";
import { paymentAdviceApi } from "./paymentAdviceApi";

export const store = configureStore({
  reducer: {
    [businessProfilesApi.reducerPath]: businessProfilesApi.reducer,
    [transportersApi.reducerPath]: transportersApi.reducer,
    [promotersApi.reducerPath]: promotersApi.reducer,
    [categoryApi.reducerPath]: categoryApi.reducer,
    [productsApi.reducerPath]: productsApi.reducer,
    [userProfilesCommonApi.reducerPath]: userProfilesCommonApi.reducer,
    [authApi.reducerPath]: authApi.reducer,
    [contractsApi.reducerPath]: contractsApi.reducer,
    [contractTrucksApi.reducerPath]: contractTrucksApi.reducer,
    [trucksApi.reducerPath]: trucksApi.reducer,
    [driversApi.reducerPath]: driversApi.reducer,
    [truckTripApi.reducerPath]: truckTripApi.reducer,
    [driverTruckMappingApi.reducerPath]: driverTruckMappingApi.reducer,
    [roleAccessApi.reducerPath]: roleAccessApi.reducer,
    [userAccessApi.reducerPath]: userAccessApi.reducer,
    [sellerInvoiceApi.reducerPath]: sellerInvoiceApi.reducer,
    [paymentAdviceApi.reducerPath]: paymentAdviceApi.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(
      businessProfilesApi.middleware,
      transportersApi.middleware,
      promotersApi.middleware,
      userProfilesCommonApi.middleware,
      authApi.middleware,
      categoryApi.middleware,
      productsApi.middleware,
      contractsApi.middleware,
      contractTrucksApi.middleware,
      trucksApi.middleware,
      driversApi.middleware,
      truckTripApi.middleware,
      driverTruckMappingApi.middleware,
      roleAccessApi.middleware,
      userAccessApi.middleware,
      sellerInvoiceApi.middleware,
      paymentAdviceApi.middleware,
    ),
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
